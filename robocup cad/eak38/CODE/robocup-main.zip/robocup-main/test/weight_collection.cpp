/************************************
 *        weight_collection.cpp       *
 *************************************/

 /* This is for functions and tasks for
  *  finding and collecting weights  */


#include "weight_collection.h"
#include "Arduino.h"
#include "motors.h"

void weight_scan(/* whatever parameters */) 
{
}


void collect_weight()
{

}


