servo locations
544 = far back (push off)
1610 = flush / bypass